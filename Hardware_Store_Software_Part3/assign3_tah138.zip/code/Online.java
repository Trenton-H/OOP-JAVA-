
import java.util.*;

/**
 * 
 */
public class Online extends Transaction {

    /**
     * Default constructor
     */
    public Online() {
    }

    /**
     * 
     */
    public void sale() {
        // TODO implement here
    }

}