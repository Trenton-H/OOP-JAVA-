
import java.util.*;

/**
 * 
 */
public class Inventory {

    /**
     * Default constructor
     */
    public Inventory() {
    }

    /**
     * 
     */
    private void ItemID;

    /**
     * 
     */
    private void ItemName;

    /**
     * 
     */
    private void Quantity;

    /**
     * 
     */
    private void Price;

}