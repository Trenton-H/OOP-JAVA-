
import java.util.*;

/**
 * 
 */
public class Appliances extends Inventory {

    /**
     * Default constructor
     */
    public Appliances() {
    }

    /**
     * 
     */
    private void Brand;

    /**
     * 
     */
    private void Type;

    /**
     * 
     */
    public void addAppliance() {
        // TODO implement here
    }

    /**
     * 
     */
    public void deleteAppliance() {
        // TODO implement here
    }

}