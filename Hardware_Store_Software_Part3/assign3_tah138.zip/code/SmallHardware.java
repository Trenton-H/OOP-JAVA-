
import java.util.*;

/**
 * 
 */
public class SmallHardware extends Inventory {

    /**
     * Default constructor
     */
    public SmallHardware() {
    }

    /**
     * 
     */
    private void Category;

    /**
     * 
     */
    public void addItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void deleteItem() {
        // TODO implement here
    }

}