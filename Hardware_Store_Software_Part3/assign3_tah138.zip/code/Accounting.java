
import java.util.*;

/**
 * 
 */
public class Accounting {

    /**
     * Default constructor
     */
    public Accounting() {
    }

    /**
     * 
     */
    private void expenses;

    /**
     * 
     */
    private void income;

    /**
     * 
     */
    private void profit;

    /**
     * 
     */
    private void balanceSheets;

    /**
     * 
     */
    private void cashFlow;

    /**
     * 
     */
    private void invoices;

    /**
     * 
     */
    public void adminCheck() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayExpenses() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayIncome() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayProfit() {
        // TODO implement here
    }

    /**
     * 
     */
    public void printBalance() {
        // TODO implement here
    }

    /**
     * 
     */
    public void printCashFlow() {
        // TODO implement here
    }

    /**
     * 
     */
    public void printInvoice() {
        // TODO implement here
    }

}