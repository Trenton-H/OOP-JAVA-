
import java.util.*;

/**
 * 
 */
public class Transaction {

    /**
     * Default constructor
     */
    public Transaction() {
    }

    /**
     * 
     */
    private void ItemID;

    /**
     * 
     */
    private void Date;

    /**
     * 
     */
    private void Quantity;

    /**
     * 
     */
    private void CustomerID;

    /**
     * 
     */
    private void EmployeeID;

    /**
     * 
     */
    private void Status;

}