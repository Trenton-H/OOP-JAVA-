
import java.util.*;

/**
 * 
 */
public class Website {

    /**
     * Default constructor
     */
    public Website() {
    }

    /**
     * 
     */
    public void account() {
        // TODO implement here
    }

    /**
     * 
     */
    public void purchase() {
        // TODO implement here
    }

    /**
     * 
     */
    public void contactStore() {
        // TODO implement here
    }

}