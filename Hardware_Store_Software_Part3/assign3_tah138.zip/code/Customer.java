
import java.util.*;

/**
 * 
 */
public class Customer extends User {

    /**
     * Default constructor
     */
    public Customer() {
    }

    /**
     * 
     */
    private void address;

    /**
     * 
     */
    private void phoneNumber;

    /**
     * 
     */
    public void gatherInfo() {
        // TODO implement here
    }

}