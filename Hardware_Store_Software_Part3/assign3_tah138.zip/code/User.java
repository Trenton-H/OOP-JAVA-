
import java.util.*;

/**
 * 
 */
public class User {

    /**
     * Default constructor
     */
    public User() {
    }

    /**
     * 
     */
    private void id;

    /**
     * 
     */
    private void firstName;

    /**
     * 
     */
    private void lastName;

}