
import java.util.*;

/**
 * 
 */
public class Driver {

    /**
     * Default constructor
     */
    public Driver() {
    }

    /**
     * 
     */
    public void displayInventory() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void deleteItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void searchItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayUsers() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addUser() {
        // TODO implement here
    }

    /**
     * 
     */
    public void updateUser() {
        // TODO implement here
    }

    /**
     * 
     */
    public void completeSale() {
        // TODO implement here
    }

    /**
     * 
     */
    public void releaseOrder() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayTransactions() {
        // TODO implement here
    }

    /**
     * 
     */
    public void accessAccounting() {
        // TODO implement here
    }

    /**
     * 
     */
    public void accessWebsite() {
        // TODO implement here
    }

}