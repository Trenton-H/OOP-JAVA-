
import java.util.*;

/**
 * 
 */
public class InStore extends Transaction {

    /**
     * Default constructor
     */
    public InStore() {
    }

    /**
     * 
     */
    public void sale() {
        // TODO implement here
    }

}