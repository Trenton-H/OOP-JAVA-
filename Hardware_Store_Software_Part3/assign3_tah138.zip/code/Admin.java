
import java.util.*;

/**
 * 
 */
public class Admin extends Employee {

    /**
     * Default constructor
     */
    public Admin() {
    }

    /**
     * 
     */
    public void verifyAdmin() {
        // TODO implement here
    }

}