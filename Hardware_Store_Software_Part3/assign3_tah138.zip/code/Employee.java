
import java.util.*;

/**
 * 
 */
public class Employee extends User {

    /**
     * Default constructor
     */
    public Employee() {
    }

    /**
     * 
     */
    private void SSN;

    /**
     * 
     */
    private void salary;

    /**
     * 
     */
    private void status;

    /**
     * 
     */
    private void pin;

    /**
     * 
     */
    public void gatherInfo() {
        // TODO implement here
    }

}